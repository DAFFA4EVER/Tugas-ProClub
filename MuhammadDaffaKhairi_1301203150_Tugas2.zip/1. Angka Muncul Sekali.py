def soal1(data):
    c = []
    for i in data:
        x = 0
        for j in data:
            if i == j:
                x += 1
        if x <= 1 :
            c.append(int(i))
    return c

data = input()
print(soal1(data))