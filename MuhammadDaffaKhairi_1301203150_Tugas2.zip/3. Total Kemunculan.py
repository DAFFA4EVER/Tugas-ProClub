def soal3(data):
    for i in set(data):
        n = 0
        for j in data:
            if i == j:
                n += 1
        print(f"{i} : {n}")

data = ['danu', 'danu', 'alif', 'indra', 'indra', 'kurniadi', 'indra']
soal3(data)