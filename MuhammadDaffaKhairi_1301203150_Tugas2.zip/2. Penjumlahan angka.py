def soal2(data, target):
    c = []
    for i in range(len(data)):
        for j in range(len(data)):
            if data[i] + data[j] == target:
                a = [i,j]
                c.append(a)
    return c

data = [2, 5, 9, 11]
target = 11
print(soal2(data,target))