def half(n):
    """
    *
    * *
    * * *
    * * * *
    * * * * *
    """
    for i in range(n):
        i += 1
        while(i != 0):
            print("*", end=" ")
            i -= 1
        print("")


def half_inverted(n):
    """
    * * * * *
    * * * *
    * * *
    * *
    *
    """
    while(n != 0):
        i = n
        while(i != 0):
            print("*", end=" ")
            i -= 1
        print("")
        n -= 1


def half_mirror(n):
    spasi = n+3
    i = 1
    """
            *
          * *
        * * *
      * * * *
    * * * * *
    """
    while(n != 0):
        for x in range(spasi):
            print(" ", end="")
        spasi -= 2
        for x in range(i):
            print("*", end=" ")
        i += 1
        print("")
        n -= 1


def full(n):
    """
            *
           * *
          * * *
         * * * *
        * * * * *
    """
    spasi = n
    i = 1
    while(n != 0):
        for x in range(spasi):
            print(" ", end="")
        spasi -= 1
        for x in range(i):
            print("*", end=" ")
        i += 1
        print("")
        n -= 1


def full_mirror(n):
    """
    * * * * *
     * * * *
      * * * 
       * * 
        * 
    """
    spasi = 1
    i = n
    while(n != 0):
        for x in range(spasi):
            print(" ", end="")
        spasi += 1
        for x in range(i):
            print("*", end=" ")
        i -= 1
        print("")
        n -= 1


half_mirror(5)
